use std::fs::File;
use std::io::prelude::*;

fn main() -> std::io::Result<()> {
    // Chaîne à écrire dans le fichier
    let s = "Hello, world!";
    
    // Convertir la chaîne en tableau d'octets
    let bytes = s.as_bytes();

    // Inverser chaque octet
    let inverted_bytes: Vec<u8> = bytes.iter().map(|&byte| !byte).collect();

    // Ouvrir le fichier en mode écriture
    let mut file = File::create("output.txt")?;

    // Écrire les octets inversés dans le fichier
    file.write_all(&inverted_bytes)?;

    Ok(())
}

