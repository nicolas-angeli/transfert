use std::fs::File;
use std::io::{Read, Write};

fn main() -> std::io::Result<()> {
    // Open the inverted file for reading
    let mut file = File::open("output.txt")?;

    // Read the contents of the file into a buffer
    let mut buffer = Vec::new();
    file.read_to_end(&mut buffer)?;

    // Invert each byte in the buffer
    let reinverted_bytes: Vec<u8> = buffer.iter().map(|&byte| !byte).collect();

    // Open a new file for writing the reinverted contents
    let mut output_file = File::create("reinverted_output.txt")?;

    // Write the reinverted bytes to the new file
    output_file.write_all(&reinverted_bytes)?;

    Ok(())
}

