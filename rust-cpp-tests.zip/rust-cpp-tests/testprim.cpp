#include <fstream>
#include <iostream>
using namespace std;

int main() {
    char data[100];

    // Open a file in write mode.
    ofstream outfile;
    outfile.open("testfile");

    cout << "Writing to the file" << endl;

    cout << "Enter your name: ";
    cin.getline(data, 100);

    // Write inputted data into the file character by character.
    for (int i = 0; data[i] != '\0'; ++i) {
        outfile.put(data[i]);
    }
    outfile.put('\n'); // Add a newline after the name.

    cout << "Enter your age: ";
    cin >> data;
    cin.ignore();

    // Again write inputted data into the file character by character.
    for (int i = 0; data[i] != '\0'; ++i) {
        outfile.put(data[i]);
    }
    outfile.put('\n'); // Add a newline after the age.

    // Close the opened file.
    outfile.close();

    // Open the file in read mode.
    ifstream infile;
    infile.open("testfile");

    cout << "Reading from the file" << endl;

    // Read characters from the file until newline character.
    char ch;
    while (infile.get(ch) && ch != '\n') {
        cout << ch;
    }
    cout << endl;

    // Read characters from the file until newline character.
    while (infile.get(ch) && ch != '\n') {
        cout << ch;
    }
    cout << endl;

    // Close the opened file.
    infile.close();

    return 0;
}

